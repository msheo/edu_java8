package Starcraft.terran;

public interface HealerInterface {

	public void move();
	public void heal();
	
}
