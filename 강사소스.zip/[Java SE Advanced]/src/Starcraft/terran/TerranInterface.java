package Starcraft.terran;

public interface TerranInterface {

	public void move();
	public  void attack();
	
}
