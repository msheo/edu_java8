package starcraft.terran;

public interface HealerInterface {
	
	public void move();
	public void heal();
}
