package starcraft.terran;

public interface TerranInterface {
	
	public void move();
	public void attack();
	
}
