package simplebooksearch.dao;

import java.sql.Connection;

public interface ConnectionMaker4 {
	
	public Connection getConnection() throws Exception;
	
}
